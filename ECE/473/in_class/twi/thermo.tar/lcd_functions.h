//LCD function header file
//for mega128 board
//R. Traylor 10.7.09

void cursor_home(void);
void home_line2(void);      
void fill_spaces(void);
void string2lcd(char *lcd_str);
void strobe_lcd(void);
void clear_display(void);
void cursor_home(void);
void home_line2(void);
void fill_spaces(void);
void char2lcd(char a_char);
void string2lcd(char *lcd_str);
void lcd_init(void);
void cursor_off(void);

